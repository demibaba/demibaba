import AttachmentTestScreen from '../../app/onboarding/attachment-test';
export default AttachmentTestScreen;